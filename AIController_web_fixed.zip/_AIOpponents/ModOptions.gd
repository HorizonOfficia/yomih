extends "res://SoupModOptions/ModOptions.gd"

func _ready():
	var my_menu = generate_menu("_AIOptions", "AI Opponent Options")
	my_menu.add_label("lbl1", "AI Opponent Options Menu")
	
	var player_dropdown = my_menu.add_dropdown_menu("target_player", "AI Player")
	player_dropdown.add_item("Off")
	player_dropdown.add_item("Player 1")
	player_dropdown.add_item("Player 2")


	var dropdown = my_menu.add_dropdown_menu("difficulty", "Difficulty")
	dropdown.add_item("Easy")
	dropdown.add_item("Medium")
	dropdown.add_item("Hard")
	
	my_menu.add_label("lbl3", "The harder the setting, the longer an AI will take to think, but the more possibilities it will consider. Hard mode takes especially long sometimes!")
	
	var experimental_button = my_menu.add_bool("experimental_speedup", "Performance Increase", true)
	my_menu.add_label("lbl4", "By deleting a line of YOMI's code, you can double decision speed! It hasn't caused any problems yet.")
	
	var talk_button = my_menu.add_bool("trash_talk", "Trash Talk", false)
	var generate_button = my_menu.add_bool("generate_messages", "Generate Messages", false)
	my_menu.add_label("lbl4", "If you ask it to \"generate\" messages, it sometimes randomly generates its own phrases, some better than others.")
	
	add_menu(my_menu)
	
func __AIOptions_opened(_menu):
	pass

func __AIOptions_closed(_menu):
	pass

func __AIOptions_late_init(_menu):
	pass

export var min_value = 0
export var max_value = 100
