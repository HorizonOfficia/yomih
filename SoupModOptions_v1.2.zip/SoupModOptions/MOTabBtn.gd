extends Button

var menu_node:Node

func _ready():
	pass
